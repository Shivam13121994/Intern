class Order {
  constructor(
    visiting_card_id,
    company_name,
    person_name,
    phone_number,
    email_address,
    address
  ) {
    this.visiting_card_id = visiting_card_id;
    this.company_name = company_name;
    this.person_name = person_name;
    this.phone_number = phone_number;
    this.email_address = email_address;
    this.address = address;
  }
}
module.exports = Order;
