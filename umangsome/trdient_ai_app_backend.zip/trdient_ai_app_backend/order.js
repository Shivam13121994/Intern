class Order {
  constructor(login_id, username, password) {
    this.login_id = login_id;
    this.username = username;
    this.password = password;
  }
}
module.exports = Order;
