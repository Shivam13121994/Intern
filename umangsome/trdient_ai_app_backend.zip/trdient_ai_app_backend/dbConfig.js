var config = {
  server: "172.16.129.195",
  database: "DB_MobileAi",
  user: "sa",
  password: "Trident@5050",
  options: {
    trustServerCertificate: true,
  },
};
module.exports = config;
