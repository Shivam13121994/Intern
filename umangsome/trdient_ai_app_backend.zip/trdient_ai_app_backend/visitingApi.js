const dbOperations = require("./dbVistingCardOperations");
var Order = require("./order");
var jwt = require("jsonwebtoken");

var express = require("express");
var bodyParser = require("body-parser");
var cors = require("cors");
var app = express();
var router = express.Router();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use("/api", router);

router.use((request, response, next) => {
  console.log("middleware");
  next();
});
router.route("/visitingcard").get((request, response) => {
  dbOperations.getOrders().then((result) => {
    response.json(result[0]);
    // authData;
  });
});

router.route("/visitingcard/:unique_id").get((request, response) => {
  // jwt.verify(request.token, "secretkey", (err, authData) => {
  //   if (err) {
  //     response.sendStatus(403);
  //   } else {
  dbOperations.getOrder(request.params.unique_id).then((result) => {
    response.json(result[0]);
  });
  // }
  // });
});

router.route("/visitingcard/add").post((request, response) => {
  // jwt.verify(request.token, "secretkey", (err, authData) => {
  //   if (err) {
  //     response.sendStatus(403);
  //   } else {
  let order = { ...request.body };
  dbOperations.addOrder(order).then((result) => {
    response.status(201).json(result);
  });
  //   }
  // });
});

router.route("/visitingcard/delete/:id").delete((request, response) => {
  // jwt.verify(request.token, "secretkey", (err, authData) => {
  //   if (err) {
  //     response.sendStatus(403);
  //   } else {
  dbOperations.deleteOrder(request.params.id).then((result) => {
    response.json(result[0]);
  });
  //   }
  // });
});

router.route("/visitingcard/update/:id").put(
  /*verifyToken,*/ (request, response) => {
    // jwt.verify(request.token, "secretkey", (err, authData) => {
    //   if (err) {
    //     response.sendStatus(403);
    //   } else {
    let order = request.body;
    console.log(order);
    dbOperations
      .updateOrder(request.params.id, order)
      .then((result) => {
        console.log(result);
        response.json(result);
      })
      .catch((error) => {
        response.status(500).json({ error: error.message });
      });
    //   }
    // });
  }
);

var port = process.env.PORT || 3001;
app.listen(port);
console.log("Order API is running at " + port);

dbOperations.getOrders().then((result) => {
  console.log(result);
});
