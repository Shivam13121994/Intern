class Order {
  constructor(login_id, username, extracted_data, confidence) {
    this.login_id = login_id;
    this.username = username;
    this.extracted_data = extracted_data;
    this.confidence = confidence;
  }
}
module.exports = Order;
