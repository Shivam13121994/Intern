const { request } = require("express");
var config_value = require("./dbConfig");
const sql = require("mssql");

async function getOrders() {
  try {
    let pool = await sql.connect(config_value);
    let towels = pool.request().query("SELECT * FROM dbo.LoginQR");
    return (await towels).recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function getOrder(orderId) {
  try {
    let pool = await sql.connect(config_value);
    let towel = pool
      .request()
      .input("input_parameter", sql.Int, orderId)
      .query(
        "SELECT count(*) FROM dbo.LoginQR where unique_id = @input_parameter"
      );
    return (await towel).recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function addOrder(order) {
  try {
    let pool = await sql.connect(config_value);
    let insertSection = pool
      .request()
      .input("device_name", sql.VarChar, order.device_name)
      .input("unique_id", sql.Int, order.unique_id)
      .input("encrypted_code", sql.VarChar, order.encrypted_code)
      .query(
        "INSERT INTO dbo.LoginQR (device_name,unique_id,encrypted_code) VALUES (@device_name,@unique_id,@encrypted_code)"
      );
    return (await insertSection).recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function deleteOrder(orderValue) {
  try {
    let pool = await sql.connect(config_value);
    let deleteRow = pool
      .request()
      .input("input_parameter", sql.Int, orderValue)
      .query("DELETE FROM dbo.LoginQR where qrcode_id = @input_parameter");
    return (await deleteRow).recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function updateOrder(newOrder, order) {
  try {
    let pool = await sql.connect(config_value);
    let updateRow = pool
      .request()
      .input("device_name", sql.VarChar, newOrder)
      // .input("password", sql.VarChar, order.section_name)
      .query(
        "UPDATE dbo.LoginQR SET device_name=@device_name where qrcode_id = @qrcode_id "
      );
    return (await updateRow).recordsets;
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  getOrders: getOrders,
  getOrder: getOrder,
  addOrder: addOrder,
  deleteOrder: deleteOrder,
  updateOrder: updateOrder,
};
