const { request } = require("express");
var config_value = require("./dbConfig");
const sql = require("mssql");

async function getOrders() {
  try {
    let pool = await sql.connect(config_value);
    let towels = pool.request().query("SELECT * FROM dbo.LoginExtractedData");
    return (await towels).recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function getOrder(orderId) {
  try {
    let pool = await sql.connect(config_value);
    let towel = pool
      .request()
      .input("input_parameter", sql.Int, orderId)
      .query(
        "SELECT * FROM dbo.LoginExtractedData where login_id = @input_parameter"
      );
    return (await towel).recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function addOrder(order) {
  try {
    let pool = await sql.connect(config_value);
    let insertSection = pool
      .request()
      .input("username", sql.VarChar, order.username)
      .input("extracted_data", sql.VarChar, order.extracted_data)
      .query(
        "INSERT INTO dbo.LoginExtractedData (username,extracted_data) VALUES (@username,@extracted_data)"
      );
    return (await insertSection).recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function deleteOrder(orderValue) {
  try {
    let pool = await sql.connect(config_value);
    let deleteRow = pool
      .request()
      .input("input_parameter", sql.Int, orderValue)
      .query(
        "DELETE FROM dbo.LoginExtractedData where login_id = @input_parameter"
      );
    return (await deleteRow).recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function updateOrder(newOrder, order) {
  try {
    let pool = await sql.connect(config_value);
    let updateRow = pool
      .request()
      .input("login_id", sql.Int, newOrder)
      .input("password", sql.VarChar, order.password)
      .query(
        "UPDATE dbo.LoginExtractedData SET password=@password where login_id = @login_id "
      );
    return (await updateRow).recordsets;
  } catch (error) {
    console.log(error);
  }
}

module.exports = {
  getOrders: getOrders,
  getOrder: getOrder,
  addOrder: addOrder,
  deleteOrder: deleteOrder,
  updateOrder: updateOrder,
};
