class Order {
  constructor(unique_id, qrcode_id, device_name, encrypted_code) {
    this.unique_id = unique_id;
    this.qrcode_id = qrcode_id;
    this.device_name = device_name;
    this.encrypted_code = encrypted_code;
  }
}
module.exports = Order;
