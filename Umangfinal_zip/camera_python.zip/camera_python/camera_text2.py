# import cv2

# def main(args):

#     #cap = cv2.VideoCapture(0) #default camera
#     cap = cv2.VideoCapture('rtsp://user:password@ipaddress:rtspPort') #IP Camera
    
#     while(True):
#         ret, frame = cap.read()
#         frame=cv2.resize(frame, (960, 540)) 
#         cv2.imshow('Capturing',frame)
        
#         if cv2.waitKey(1) & 0xFF == ord('q'): #click q to stop capturing
#             break

#     cap.release()
#     cv2.destroyAllWindows()
#     return 0

# if __name__ == '__main__':
#     import sys
#     sys.exit(main(sys.argv))

import cv2 
import time
import os
import boto3

os.environ['AWS_ACCESS_KEY_ID'] = 'YOUR_ACCESS_KEY_ID'
os.environ['AWS_SECRET_ACCESS_KEY'] = 'YOUR_SECRET_ACCESS_KEY'
os.environ['AWS_DEFAULT_REGION'] = 'ap-south-1'

def initialize_textract_client():
    return boto3.client('textract')

def detect_text(image_bytes):
    try:
        textract_client = initialize_textract_client()
        response = textract_client.detect_document_text(Document={'Bytes': image_bytes})
        return response
    except Exception as e:
        return {'error': str(e)}

def extract_text_by_block_type(response, block_type):
    extracted_text = ""
    for item in response['Blocks']:
        if item['BlockType'] == block_type:
            extracted_text += item['Text'] + " "
    return extracted_text.strip()

def capture_photo(frame):
    global frame_counter
    cv2.imwrite(f"captured_photo_{frame_counter}.jpg", frame)
    print(f"Photo {frame_counter} captured!")
    image_bytes = cv2.imencode('.jpg', frame)[1].tobytes()
    return image_bytes

frame_counter = 1
interval = 10  
vid = cv2.VideoCapture('rtsp://user:password@ipaddress:rtspPort') # IP Camera

while True: 
    ret, frame = vid.read() 

    cv2.imshow('frame', frame) 

    if cv2.waitKey(1) & 0xFF == ord('q'): 
        break

    if ret:
        if frame_counter % interval == 0:
            frame_bytes = capture_photo(frame)
            if frame_bytes:
                response = detect_text(frame_bytes)
                if 'error' in response:
                    print('Text detection failed:', response['error'])
                else:
                    block_type = 'WORD'
                    extracted_text = extract_text_by_block_type(response, block_type)
                    print('Text extracted successfully:', extracted_text)
            else:
                print('Failed to capture photo')
        frame_counter += 1

vid.release() 
cv2.destroyAllWindows()
