# import the opencv library 
import cv2 
from PIL import Image

# define a video capture object 
vid = cv2.VideoCapture(0) 

while(True): 
	
	
	ret, frame = vid.read() 

	cv2.imshow('frame', frame) 
	
	
	if cv2.waitKey(1) & 0xFF == ord('q'): 
		break

# After the loop release the cap object 
vid.release() 
# Destroy all the windows 
cv2.destroyAllWindows() 




# def most_common_used_color(img):
	
# 	width, height = img.size

# 	r_total = 0
# 	g_total = 0
# 	b_total = 0

# 	count = 0

	
# 	for x in range(0, width):
# 		for y in range(0, height):
			
# 			r, g, b = img.getpixel((x, y))
# 			print(r,g,b)

# 			r_total += r
# 			g_total += g
# 			b_total += b
# 			count += 1

# 	return (r_total/count, g_total/count, b_total/count)


# img = Image.open("bed_image.jpeg")

# img = img.convert('RGB')

# common_color = most_common_used_color(img)

# print(common_color)


# from PIL import Image

# def most_common_used_color(img):
#     width, height = img.size

#     color_count = {}

#     for x in range(width):
#         for y in range(height):
#             r, g, b = img.getpixel((x, y))
#             color = (r, g, b)
            
#             if color in color_count:
#                 color_count[color] += 1
#             else:
#                 color_count[color] = 1

#     return color_count

# img = Image.open("bed_image.jpeg")
# img = img.convert('RGB')

# common_colors = most_common_used_color(img)

# for color, count in common_colors.items():
#     print(f"Color: {color}, Count: {count}")

# from PIL import Image
# import webcolors

# def closest_color(rgb_tuple):
#     min_colors = {}
#     for key, name in webcolors.CSS3_HEX_TO_NAMES.items():
#         r_c, g_c, b_c = webcolors.hex_to_rgb(key)
#         rd = (r_c - rgb_tuple[0]) ** 2
#         gd = (g_c - rgb_tuple[1]) ** 2
#         bd = (b_c - rgb_tuple[2]) ** 2
#         min_colors[(rd + gd + bd)] = name
#     return min_colors[min(min_colors.keys())]

# def most_common_used_color(img):
#     width, height = img.size

#     color_count = {}

#     for x in range(width):
#         for y in range(height):
#             r, g, b = img.getpixel((x, y))
#             color = (r, g, b)
            
#             if color in color_count:
#                 color_count[color] += 1
#             else:
#                 color_count[color] = 1

#     return color_count

# img = Image.open("mytrident.jpeg")
# img = img.convert('RGB')

# common_colors = most_common_used_color(img)

# max_count_color = max(common_colors, key=common_colors.get)
# max_count = common_colors[max_count_color]

# max_count_color_name = closest_color(max_count_color)

# print(f"Most common color: {max_count_color}, Name: {max_count_color_name}, Count: {max_count}")

# from PIL import Image
# import webcolors

# def closest_vibgyor_color(rgb_tuple):
#     vibgyor_colors = {
#         'Violet': (148, 0, 211),
#         'Indigo': (75, 0, 130),
#         'Blue': (0, 0, 255),
#         'Green': (0, 255, 0),
#         'Yellow': (255, 255, 0),
#         'Orange': (255, 165, 0),
#         'Red': (255, 0, 0)
#     }

#     min_distance = float('inf')
#     closest_color_name = None

#     for color_name, color_rgb in vibgyor_colors.items():
#         distance = sum((a - b) ** 2 for a, b in zip(rgb_tuple, color_rgb))
#         if distance < min_distance:
#             min_distance = distance
#             closest_color_name = color_name

#     return closest_color_name

# def most_common_used_color(img):
#     width, height = img.size

#     color_count = {}

#     for x in range(width):
#         for y in range(height):
#             r, g, b = img.getpixel((x, y))
#             color = (r, g, b)
            
#             if color in color_count:
#                 color_count[color] += 1
#             else:
#                 color_count[color] = 1

#     return color_count

# img = Image.open("mytrident.jpeg")
# img = img.convert('RGB')

# common_colors = most_common_used_color(img)

# for color_rgb, count in common_colors.items():
#     color_name = closest_vibgyor_color(color_rgb)
#     print(f"Color: {color_rgb}, Nearest VIBGYOR Color: {color_name}, Count: {count}")


from PIL import Image
import webcolors
# import the opencv library 
import cv2 
from PIL import Image

# define a video capture object 
vid = cv2.VideoCapture(0) 

while(True): 
	
	
	ret, frame = vid.read() 

	cv2.imshow('frame', frame) 
	
	
	if cv2.waitKey(1) & 0xFF == ord('q'): 
		break

# After the loop release the cap object 
vid.release() 
# Destroy all the windows 
cv2.destroyAllWindows() 

def closest_vibgyor_color(rgb_tuple):
    vibgyor_colors = {
        'Violet': (148, 0, 211),
        'Indigo': (75, 0, 130),
        'Blue': (0, 0, 255),
        'Green': (0, 255, 0),
        'Yellow': (255, 255, 0),
        'Orange': (255, 165, 0),
        'Red': (255, 0, 0)
    }

    min_distance = float('inf')
    closest_color_name = None

    for color_name, color_rgb in vibgyor_colors.items():
        distance = sum((a - b) ** 2 for a, b in zip(rgb_tuple, color_rgb))
        if distance < min_distance:
            min_distance = distance
            closest_color_name = color_name

    return closest_color_name

def most_common_used_color(img):
    width, height = img.size

    vibgyor_count = {
        'Violet': 0,
        'Indigo': 0,
        'Blue': 0,
        'Green': 0,
        'Yellow': 0,
        'Orange': 0,
        'Red': 0
    }

    for x in range(width):
        for y in range(height):
            r, g, b = img.getpixel((x, y))
            color = (r, g, b)
            nearest_color_name = closest_vibgyor_color(color)
            vibgyor_count[nearest_color_name] += 1

    return vibgyor_count

img = Image.open("orange.jpeg")
img = img.convert('RGB')

vibgyor_counts = most_common_used_color(img)

for color_name, count in vibgyor_counts.items():
    print(f"VIBGYOR Color: {color_name}, Count: {count}")

