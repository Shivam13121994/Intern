# # import the opencv library 
# import cv2 
# from PIL import Image

# # define a video capture object 
# vid = cv2.VideoCapture(0) 

# def capture_photo(event, x, y, flags, param):
#     global photo_taken, frame
#     if event == cv2.EVENT_LBUTTONDOWN:
#         photo_taken = True
#         cv2.imwrite("captured_photo.jpg", frame)
#         print("Photo captured!")

# # Create a window and set mouse callback to capture photo
# cv2.namedWindow('frame')
# cv2.setMouseCallback('frame', capture_photo)

# photo_taken = False

# while(True): 
#     ret, frame = vid.read() 

#     cv2.imshow('frame', frame) 

#     if photo_taken:
#         break

#     if cv2.waitKey(1) & 0xFF == ord('q'): 
#         break

# # After the loop release the cap object 
# vid.release() 
# # Destroy all the windows 
# cv2.destroyAllWindows() 



 
# import cv2 
# import time
# import os
# import boto3
# from flask import Flask, jsonify, request
# os.environ['AWS_ACCESS_KEY_ID'] = 'AKIAQ3EGWHSNRCBIRJIV'
# os.environ['AWS_SECRET_ACCESS_KEY'] = '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'
# os.environ['AWS_DEFAULT_REGION'] = 'ap-south-1'

# vid = cv2.VideoCapture(0)


# def initialize_textract_client():
#     return boto3.client('textract')

# def detect_text(image_bytes):
#     try:
#         textract_client = initialize_textract_client()
#         response = textract_client.detect_document_text(Document={'Bytes': image_bytes})
#         return response
#     except Exception as e:
#         return {'error': str(e)}
    
# def extract_text_by_block_type(response, block_type):
#     extracted_text = ""
#     for item in response['Blocks']:
#         if item['BlockType'] == block_type:
#             extracted_text += item['Text'] + " "
#     return extracted_text.strip()

# def load_image_from_path(image_path):
#     try:
#         with open(image_path, 'rb') as file:
#             image_bytes = file.read()
#         return image_bytes
#     except Exception as e:
#         return None

# def capture_photo():
#     global frame_counter, frame
#     cv2.imwrite(f"captured_photo_{frame_counter}.jpg", frame)
#     print(f"Photo {frame_counter} captured!")
#     # image_bytes=load_image_from_path(f"captured_photo_{frame_counter}.jpg")
#     # if not image_bytes:
#     #     return jsonify({'message': 'Failed to load image'})
    
#     # response=detect_text(image_bytes)

#     # if 'error' in response:
#     #     return jsonify({'message': 'Text detection failed'})
        
#     # block_type = 'WORD'
#     # extracted_text = extract_text_by_block_type(response, block_type)

#     # print(jsonify({'message': 'Text extracted successfully', 'text': extracted_text}))
#     frame_counter += 1

# frame_counter = 1
# start_time = time.time()
# interval = 10  

# while True: 
#     ret, frame = vid.read() 

#     cv2.imshow('frame', frame) 

#     if time.time() - start_time >= interval:
#         capture_photo()
#         start_time = time.time()

#     if cv2.waitKey(1) & 0xFF == ord('q'): 
#         break


# vid.release() 
# cv2.destroyAllWindows() 



# import requests

# def load_image_from_path(image_path):
#     try:
#         with open(image_path, 'rb') as file:
#             image_bytes = file.read()
#         return image_bytes
#     except Exception as e:
#         return None

# def perform_ocr(file):
#     headers = {
#         "apikey": "FEmvQr5uj99ZUvk3essuYb6P5lLLBS20",
#         "Content-Type": "multipart/form-data"
#     }

#     response = requests.post("https://api.apilayer.com/image_to_text/upload", files={"file": file}, headers=headers)
#     result = response.json()

#     return result["all_text"]

# extracted_value=perform_ocr("bed_image.jpeg")
# print(extracted_value)

# import pytesseract
# from PIL import Image

# def perform_ocr(image_path):
#     try:
#         # Open the image file
#         with Image.open(image_path) as img:
#             # Perform OCR using pytesseract
#             extracted_text = pytesseract.image_to_string(img)
#             return extracted_text.strip()  # Strip whitespace
#     except Exception as e:
#         return {'error': str(e)}

# def load_image_from_path(image_path):
#     try:
#         with open(image_path, 'rb') as file:
#             image_bytes = file.read()
#         return image_bytes
#     except Exception as e:
#         return None

# # Replace 'YOUR_IMAGE_PATH' with the actual file path of the image you want to process
# image_path = 'sampletext5.png'

# # Load image from file path
# image_bytes = load_image_from_path(image_path)

# if image_bytes:
#     # Perform OCR on the image
#     extracted_text = perform_ocr(image_path)
#     print(extracted_text)
# else:
#     print("Failed to load image from path:", image_path)

import cv2 
import time
import os
import boto3

os.environ['AWS_ACCESS_KEY_ID'] = 'YOUR_ACCESS_KEY_ID'
os.environ['AWS_SECRET_ACCESS_KEY'] = 'YOUR_SECRET_ACCESS_KEY'
os.environ['AWS_DEFAULT_REGION'] = 'ap-south-1'

vid = cv2.VideoCapture(0)

def initialize_textract_client():
    return boto3.client('textract')

def detect_text(image_bytes):
    try:
        textract_client = initialize_textract_client()
        response = textract_client.detect_document_text(Document={'Bytes': image_bytes})
        return response
    except Exception as e:
        return {'error': str(e)}

def extract_text_by_block_type(response, block_type):
    extracted_text = ""
    for item in response['Blocks']:
        if item['BlockType'] == block_type:
            extracted_text += item['Text'] + " "
    return extracted_text.strip()

def capture_photo():
    global frame_counter, frame
    cv2.imwrite(f"captured_photo_{frame_counter}.jpg", frame)
    print(f"Photo {frame_counter} captured!")
    image_bytes = cv2.imencode('.jpg', frame)[1].tobytes()
    return image_bytes

frame_counter = 1
start_time = time.time()
interval = 10  

while True: 
    ret, frame = vid.read() 

    cv2.imshow('frame', frame) 

    if time.time() - start_time >= interval:
        frame_bytes = capture_photo()
        if frame_bytes:
            response = detect_text(frame_bytes)
            if 'error' in response:
                print('Text detection failed:', response['error'])
            else:
                block_type = 'WORD'
                extracted_text = extract_text_by_block_type(response, block_type)
                print('Text extracted successfully:', extracted_text)
        else:
            print('Failed to capture photo')
        start_time = time.time()

    if cv2.waitKey(1) & 0xFF == ord('q'): 
        break

vid.release() 
cv2.destroyAllWindows()

