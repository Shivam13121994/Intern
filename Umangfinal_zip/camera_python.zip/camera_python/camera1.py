# import cv2 
# from PIL import Image

# def closest_vibgyor_color(rgb_tuple):
#     vibgyor_colors = {
#         'Violet': (148, 0, 211),
#         'Indigo': (75, 0, 130),
#         'Blue': (0, 0, 255),
#         'Green': (0, 255, 0),
#         'Yellow': (255, 255, 0),
#         'Orange': (255, 165, 0),
#         'Red': (255, 0, 0)
#     }

#     min_distance = float('inf')
#     closest_color_name = None

#     for color_name, color_rgb in vibgyor_colors.items():
#         distance = sum((a - b) ** 2 for a, b in zip(rgb_tuple, color_rgb))
#         if distance < min_distance:
#             min_distance = distance
#             closest_color_name = color_name

#     return closest_color_name

# def most_common_used_color(img):
#     width, height = img.size

#     vibgyor_count = {
#         'Violet': 0,
#         'Indigo': 0,
#         'Blue': 0,
#         'Green': 0,
#         'Yellow': 0,
#         'Orange': 0,
#         'Red': 0
#     }

#     for x in range(width):
#         for y in range(height):
#             r, g, b = img.getpixel((x, y))
#             color = (r, g, b)
#             nearest_color_name = closest_vibgyor_color(color)
#             vibgyor_count[nearest_color_name] += 1

#     return vibgyor_count

# # define a video capture object 
# vid = cv2.VideoCapture(0) 

# while True: 
#     ret, frame = vid.read() 

#     cv2.imshow('frame', frame) 
    
#     # convert the frame to PIL Image
#     frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
#     img = Image.fromarray(frame)
#     img = img.convert('RGB')
    
#     vibgyor_counts = most_common_used_color(img)
    
#     for color_name, count in vibgyor_counts.items():
#         print(f"VIBGYOR Color: {color_name}, Count: {count}")

#     if cv2.waitKey(1) & 0xFF == ord('q'): 
#         break

# # After the loop release the cap object 
# vid.release() 
# # Destroy all the windows 
# cv2.destroyAllWindows() 


# import cv2 
# from PIL import Image

# def closest_vibgyor_color(rgb_tuple):
#     vibgyor_colors = {
#         'Violet': (148, 0, 211),
#         'Indigo': (75, 0, 130),
#         'Blue': (0, 0, 255),
#         'Green': (0, 255, 0),
#         'Yellow': (255, 255, 0),
#         'Orange': (255, 165, 0),
#         'Red': (255, 0, 0)
#     }

#     min_distance = float('inf')
#     closest_color_name = None

#     for color_name, color_rgb in vibgyor_colors.items():
#         distance = sum((a - b) ** 2 for a, b in zip(rgb_tuple, color_rgb))
#         if distance < min_distance:
#             min_distance = distance
#             closest_color_name = color_name

#     return closest_color_name

# def most_common_used_color(img):
#     width, height = img.size

#     vibgyor_count = {
#         'Violet': 0,
#         'Indigo': 0,
#         'Blue': 0,
#         'Green': 0,
#         'Yellow': 0,
#         'Orange': 0,
#         'Red': 0
#     }

#     for x in range(width):
#         for y in range(height):
#             r, g, b = img.getpixel((x, y))
#             color = (r, g, b)
#             nearest_color_name = closest_vibgyor_color(color)
#             vibgyor_count[nearest_color_name] += 1

#     return vibgyor_count

# # Define the initial coordinates of the focus area
# focus_area_top_left = (200, 200)
# focus_area_bottom_right = (400, 400)
# drawing = False  # True if mouse is pressed
# ix, iy = -1, -1

# def draw_rectangle(event, x, y, flags, param):
#     global ix, iy, drawing, focus_area_top_left, focus_area_bottom_right

#     if event == cv2.EVENT_LBUTTONDOWN:
#         drawing = True
#         ix, iy = x, y

#     elif event == cv2.EVENT_MOUSEMOVE:
#         if drawing:
#             focus_area_top_left = (min(ix, x), min(iy, y))
#             focus_area_bottom_right = (max(ix, x), max(iy, y))

#     elif event == cv2.EVENT_LBUTTONUP:
#         drawing = False
#         focus_area_bottom_right = (max(ix, x), max(iy, y))

# # Create a video capture object 
# vid = cv2.VideoCapture(0) 

# # Create a window and bind the function to the window
# cv2.namedWindow('frame')
# cv2.setMouseCallback('frame', draw_rectangle)

# while True: 
#     ret, frame = vid.read() 

#     # Display the focus area rectangle
#     cv2.rectangle(frame, focus_area_top_left, focus_area_bottom_right, (0, 255, 0), 2)

#     cv2.imshow('frame', frame) 
    
#     # Get the color data from the region within the focus area
#     focus_area_frame = frame[focus_area_top_left[1]:focus_area_bottom_right[1], 
#                              focus_area_top_left[0]:focus_area_bottom_right[0]]
    
#     # Convert the focus area frame to PIL Image
#     focus_area_frame_rgb = cv2.cvtColor(focus_area_frame, cv2.COLOR_BGR2RGB)
#     focus_area_img = Image.fromarray(focus_area_frame_rgb)
#     focus_area_img = focus_area_img.convert('RGB')
    
#     vibgyor_counts = most_common_used_color(focus_area_img)
    
#     for color_name, count in vibgyor_counts.items():
#         print(f"VIBGYOR Color: {color_name}, Count: {count}")

#     if cv2.waitKey(1) & 0xFF == ord('q'): 
#         break

# # Release the capture object 
# vid.release() 
# # Destroy all the windows 
# cv2.destroyAllWindows() 


import cv2 
from PIL import Image

def closest_vibgyor_color(rgb_tuple):
    vibgyor_colors = {
        'Violet': (148, 0, 211),
        'Indigo': (75, 0, 130),
        'Blue': (0, 0, 255),
        'Green': (0, 255, 0),
        'Yellow': (255, 255, 0),
        'Orange': (255, 165, 0),
        'Red': (255, 0, 0)
    }

    min_distance = float('inf')
    closest_color_name = None

    for color_name, color_rgb in vibgyor_colors.items():
        distance = sum((a - b) ** 2 for a, b in zip(rgb_tuple, color_rgb))
        if distance < min_distance:
            min_distance = distance
            closest_color_name = color_name

    return closest_color_name

def most_common_used_color(img):
    width, height = img.size

    vibgyor_count = {
        'Violet': 0,
        'Indigo': 0,
        'Blue': 0,
        'Green': 0,
        'Yellow': 0,
        'Orange': 0,
        'Red': 0
    }

    for x in range(width):
        for y in range(height):
            r, g, b = img.getpixel((x, y))
            color = (r, g, b)
            nearest_color_name = closest_vibgyor_color(color)
            vibgyor_count[nearest_color_name] += 1

    return vibgyor_count

# Define the initial coordinates of the focus area
focus_area_top_left = (200, 200)
focus_area_bottom_right = (400, 400)

def move_focus(event, x, y, flags, param):
    global focus_area_top_left, focus_area_bottom_right

    if event == cv2.EVENT_LBUTTONDOWN:
        focus_area_width = focus_area_bottom_right[0] - focus_area_top_left[0]
        focus_area_height = focus_area_bottom_right[1] - focus_area_top_left[1]

        focus_area_top_left = (x - focus_area_width // 2, y - focus_area_height // 2)
        focus_area_bottom_right = (focus_area_top_left[0] + focus_area_width, focus_area_top_left[1] + focus_area_height)

# Create a video capture object 
vid = cv2.VideoCapture(0) 

# Create a window and bind the function to the window
cv2.namedWindow('frame')
cv2.setMouseCallback('frame', move_focus)

while True: 
    ret, frame = vid.read() 

    # Display the focus area rectangle
    cv2.rectangle(frame, focus_area_top_left, focus_area_bottom_right, (0, 255, 0), 2)

    cv2.imshow('frame', frame) 
    
    # Get the color data from the region within the focus area
    focus_area_frame = frame[focus_area_top_left[1]:focus_area_bottom_right[1], 
                             focus_area_top_left[0]:focus_area_bottom_right[0]]
    
    # Convert the focus area frame to PIL Image
    focus_area_frame_rgb = cv2.cvtColor(focus_area_frame, cv2.COLOR_BGR2RGB)
    focus_area_img = Image.fromarray(focus_area_frame_rgb)
    focus_area_img = focus_area_img.convert('RGB')
    
    vibgyor_counts = most_common_used_color(focus_area_img)
    
    for color_name, count in vibgyor_counts.items():
        print(f"VIBGYOR Color: {color_name}, Count: {count}")

    if cv2.waitKey(1) & 0xFF == ord('q'): 
        break

# Release the capture object 
vid.release() 
# Destroy all the windows 
cv2.destroyAllWindows() 
