
from flask import Flask, jsonify, request
import mysql.connector

app = Flask(__name__)


def get_database_connection():
    return mysql.connector.connect(
        host="172.16.136.37",
        user="newuser1",
        password="Trident123",
        database="db_osc"
    )


@app.route('/get_combined_data', methods=['GET'])
def get_accounts():
    try:
        con = get_database_connection()
        cursor = con.cursor()
        query = """
            SELECT h.name AS hardware_name, b.ssn, h.*, a.*
            FROM hardware h
            JOIN bios b ON h.id = b.hardware_id
            JOIN acountinformation a ON h.id = a.hardware_id
        """
        cursor.execute(query)
        accounts = cursor.fetchall()
        cursor.close()
        con.close()
        # Convert accounts to a list of dictionaries for JSON serialization
        accounts_list = []
        print(accounts)
        for account in accounts:
            account_dict = {
                'hardware_name': account[0],
                'ssn': account[1],
                'hardware_id': account[2],
                'fields_7': account[5],
                'fields_8': account[6],
                'fields_10': account[7],
                'fields_11': account[8],
                'fields_12': account[9],
                'fields_13': account[10],
                'fields_15': account[11],
                'fields_17': account[12],
                'fields_18': account[13],
                'fields_20': account[14],
                'fields_27': account[15],
                'fields_31': account[16],
                'fields_32': account[17],
                
            }
            accounts_list.append(account_dict)
        return jsonify(accounts_list)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# POST API to insert new account
if __name__ == '__main__':
    app.run(host="0.0.0.0")
