from flask import Flask, jsonify,request
import boto3
from PIL import Image
import os
# import re
import uuid;
os.environ['AWS_ACCESS_KEY_ID'] = 'AKIAQ3EGWHSN5WKGBKFE'
os.environ['AWS_SECRET_ACCESS_KEY'] = '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'
os.environ['AWS_DEFAULT_REGION'] = 'ap-south-1'

app = Flask(__name__)

S3_BUCKET = 'mobile-ai-app'
S3_ACCESS_KEY = 'AKIAQ3EGWHSNTFYZURKB'
S3_SECRET_KEY = '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'
S3_REGION = 'ap-south-1'
# Initialize Textract client
def initialize_textract_client():
    return boto3.client('textract')

s3 = boto3.client(
    's3',
    aws_access_key_id=S3_ACCESS_KEY,
    aws_secret_access_key=S3_SECRET_KEY,
    region_name=S3_REGION
)


# Function to detect text in an image
def detect_text(image_bytes):
    try:
        textract_client = initialize_textract_client()
        response = textract_client.detect_document_text(Document={'Bytes': image_bytes})
        return response
    except Exception as e:
        return {'error': str(e)}

def load_image_from_folder(image_name):
    try:
        image_path = os.path.join(image_name)
        with open(image_path, 'rb') as file:
            image_bytes = file.read()
        return image_bytes
    except Exception as e:
        return None

def extract_text_by_block_type(response, block_type):
    extracted_text = []
    for item in response['Blocks']:
        if item['BlockType'] == block_type:
            text = item['Text']
            lines = text.split('\n')
            extracted_text.extend(lines)
    return extracted_text


# def extract_phone_numbers(text_list):
#     phone_numbers = []
#     for text in text_list:
#         matches = re.findall(r'\+?\d{1,3}[-\s]?\d{3,4}[-\s]?\d{4,}', text)
#         phone_numbers.extend(matches)
#     return phone_numbers


# def extract_names(text_list):
#     names = []
#     for text in text_list:
#         words = text.split()
#         if any(word.istitle() for word in words):
#             names.append(text)
#     return names

# def extract_emails(text_list):
#     emails = []
#     for text in text_list:
#         if '@' in text and '.' in text:
#             emails.append(text)
#     return emails
@app.route('/textract_text', methods=['POST'])
def read_text():
    data = request.get_json()
    # file_name=os.path.basename(file_path)
    if 'file_name' not in data:
        return jsonify({'error': 'File name not provided'}), 400
    try:
        # Retrieve uploaded image from S3
        s3_bucket_name = 'mobile-ai-app'
        s3_key = data['file_name']  # Update with your S3 image key
        s3_client = boto3.client('s3')
        image_object = s3_client.get_object(Bucket=s3_bucket_name, Key=s3_key)
        image_bytes = image_object['Body'].read()

        # Detect text in the image
        response = detect_text(image_bytes)

        if 'error' in response:
            return jsonify({'message': 'Text detection failed'})
        block_type = 'LINE'  
        extracted_text = extract_text_by_block_type(response, block_type)
   
        print("extracted_text: ",extracted_text)
   
        return jsonify({'text': extracted_text})
    except Exception as e:
        return jsonify({'error': str(e)})

# def allowed_file(filename):
#     return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'png', 'jpg', 'jpeg'}

if __name__ == '__main__':
    app.run(host="0.0.0.0")