
# from flask import Flask, request, jsonify
# import boto3

# app = Flask(__name__)

# # Initialize Textract client
# def initialize_textract_client():
#     return boto3.client('textract',
#                         aws_access_key_id='AKIAQ3EGWHSNRCBIRJIV',
#                         aws_secret_access_key='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',
#                         region_name='ap-south-1')

# # Function to detect text in an image
# def detect_text(image_bytes):
#     textract_client = initialize_textract_client()
#     response = textract_client.detect_document_text(Document={'Bytes': image_bytes})
#     return response

# @app.route('/textract_text', methods=['POST'])
# def extract_text():
#     if 'sampletext.jpg' not in request.files:
#         return jsonify({'error': 'No image file provided'}), 400
    
#     image_file = request.files['sampletext.jpg']
#     image_bytes = image_file.read()

#     if not image_bytes:
#         return jsonify({'error': 'Empty image file provided'}), 400
    
#     try:
#         response = detect_text(image_bytes)
#         return jsonify(response)
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# if __name__ == '__main__':
#     app.run()

from flask import Flask, request, jsonify
import boto3
from flask import Flask, jsonify
from PIL import Image
import os


app = Flask(__name__)

# Initialize Textract client
textract_client = boto3.client('textract',
                               aws_access_key_id='AKIAQ3EGWHSNRCBIRJIV',
                               aws_secret_access_key='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',
                               region_name='ap-south-1')

# Function to detect text in an image
def load_image_from_folder(folder_path, image_bytes):
    try:
        image_path = os.path.join(folder_path, image_bytes)
        image = Image.open(image_path)
        response = textract_client.detect_document_text(Document={'Bytes': image_bytes})
        return response
    except Exception as e:
        return "Bye"
# def detect_text(image_bytes):
#     try:
#         response = textract_client.detect_document_text(Document={'Bytes': image_bytes})
#         return response
#     except Exception as e:
#         return {'error': str(e)}
        

@app.route('/textract_text', methods=['POST'])
def extract_text():
    # print(request.files)
    
    # if 'sampletext.jpg' not in request.files:
    #     return jsonify({'error': 'No image file provided'}), 400
    
    folder_path = "images"
    image_bytes = "sampletext.jpg"
    result = load_image_from_folder(folder_path, image_bytes)
    return jsonify({'message': result})

    if not image_bytes:
        return jsonify({'error': 'Empty image file provided'}), 400
    
    response = detect_text(image_bytes)
    
    if 'error' in response:
        return jsonify(response), 500

    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)


