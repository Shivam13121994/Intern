from pdf2image import convert_from_path
import pytesseract as tes
import cv2
import pyodbc
import os
import shutil
import xlsxwriter
import boto3
from flask import Flask, request, jsonify

from datetime import datetime
os.environ['AWS_ACCESS_KEY_ID'] = 'AKIAQ3EGWHSNRCBIRJIV'
os.environ['AWS_SECRET_ACCESS_KEY'] = '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'
os.environ['AWS_DEFAULT_REGION'] = 'ap-south-1'
 
def initialize_textract_client():
    return boto3.client('textract')
def load_image_from_path(image_path):
    try:
        textract_client = initialize_textract_client()
        with open(image_path, 'rb') as file:
            image_bytes = textract_client.analyze_document(
                Document={
                    
                    'Bytes': file.read(),
                },
                FeatureTypes=["FORMS","TABLES"])
        return image_bytes
    except Exception as e:
        return None
def extract_text_by_block_type(response, block_type):
    extracted_text = ""
    for item in response['Blocks']:
        if item['BlockType'] == block_type:
            extracted_text += item['Text'] + " "
    return extracted_text.strip()
def read_text():
    try:
        json_data = request.get_json()
        image_path = json_data.get('image_path', None)
        
        if not image_path:
            return jsonify({'message': 'Image path not provided'})
        
        # Load image from path
        image_bytes = load_image_from_path(image_path)
        print(image_bytes)
        
        if not image_bytes:
            return jsonify({'message': 'Failed to load image'})
        
        # response = detect_text(image_bytes)
        # print(response)
        
        # if 'error' in response:
        #     return jsonify({'message': 'Text detection failed'})
        
        block_type = 'WORD'
        extracted_text = extract_text_by_block_type(image_bytes, block_type)
        # extracted_table=extract_table_info(image_bytes,extracted_text )
        
        return jsonify({'message': 'Text extracted successfully', 'text': extracted_text})
    except Exception as e:
        return jsonify({'error': str(e)})


try:
    now = datetime.now()
    filenam = str(str(now).replace("-",""))
    filenam = filenam.replace(" ","")
    filenam = filenam.replace(":","")
    filenam = filenam[:12]
 
 
 
    workbook = xlsxwriter.Workbook('C:/Work/ScanReport_'+filenam+'.xlsx')
   
                   
 
    worksheet = workbook.add_worksheet()
   
 
    worksheet.write('A1', 'ID')
    worksheet.write('B1', 'FileName')
    worksheet.write('C1', 'SalaryCode')
    worksheet.write('D1', 'PageCount')
    # worksheet.write('E1', 'Sequence')
   
    # Finally, close the Excel file
    # via the close() method.
 
 
    fileSplitCount = 0  
    your_path = ""
    your_path = "C:\\Work\scanned docs\\"
    New_path = "C:\\Work\scanned docs_Completed\\"
 
    #
    ID  =''
    FileName=''
    SalaryCode=''  
    PageCount=''    
    Sequence=''
 
    id = 0
 
 
    files = os.listdir(your_path)
    keyword = '.pdf'
 
    count= 0    
    for file in files:
            if file.endswith('.pdf'):
                id = id + 1    
                colIDA = 'A'+ str(id+1)
                colIDB = 'B'+ str(id+1)
                colIDC = 'C'+ str(id+1)
                colIDD = 'D'+ str(id+1)
                # colIDE = 'E'+ str(id+1)
                worksheet.write(colIDA, str(id))
                worksheet.write(colIDB,file)
 
                       
                images = convert_from_path(your_path + file, 100,output_folder=r'C:\Work\TempImages',poppler_path=r'C:\Work\poppler-0.68.0\bin')
                # images = convert_from_path(your_path + file)
# images = np.array(images)
                index = 0
               
                   
 
 
                seq =""
                for i in range(len(images)):
               
                   
                    images[i].save('C:\\Work\\TempImages\\page'+ str(i) +'.png', 'PNG')
 
 
 
                    # img = Image.open(r'C:\\Work\\TempImages\\page'+ str(i) +'.jpg')
 
                    img = cv2.imread(r'C:\\Work\\TempImages\\page'+ str(i) +'.png')
 
                        # Preprocess the image (e.g., convert to grayscale, apply thresholding, etc.)
                        # For simplicity, we'll just convert it to grayscale here
                    gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                   
                    text = ""
 
                #     tes.pytesseract.tesseract_cmd = r'C:\Users\vinaynanda\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'
                    tes.pytesseract.tesseract_cmd = r'C:\Users\CHprojectspb\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'    
                    if i==0 or i == 4:
                        x, y, width, height = 100, 100, 200, 150
 
                        roi = gray_image[y:y+height, x:x+width]
                    if i==2 :
                        x, y, width, height = 100, 800, 200, 200
 
                        roi = gray_image[y:y+height, x:x+width]
                        # cv2.imshow('ROI', roi)
                        # cv2.waitKey(0)
                        # cv2.destroyAllWindows()
 
 
 
                        text = tes.image_to_string(roi, lang='eng', config='--psm 6')
                       
                    else:        
                        text = tes.image_to_string(roi, lang='eng', config='--psm 6')
                        # file_path = r'C:\Users\vinaynanda\Desktop\pdfextract\1.txt'
                        # with open(file_path,'w') as file:
                        #        file.write(text)
                   
                   
                     
                    idx = text.find('Member Code')
                    if idx == -1:
                            idx = text.find('Member Coie')
 
                    idx2 = text.find('Place:')
 
                    page1 = text.find('This Appointment Letter is being executed based')
                    page2 = text.find('That all communications sent to you by')
                    page3 = text.find('You agree to submit to the exclusive jurisdiction')
                   
                    page4 = text.find('ANNEXURE-A')
                    page5 = text.find('ANNEXURE-B')
                   
 
                    if (page1 != -1):
                            seq = seq + '1'
                    if (page2 != -1):
                            seq = seq + '2'
                    if (page3 != -1):
                            seq = seq + '3'
                    if (page4 != -1):
                            seq = seq + '4'
                    if (page5 != -1):
                            seq = seq + '5'
                   
 
                    if idx == -1  :
                            print()
                    else:
                            Salcode=""
                            k= 13
                            print (idx)
                            var = ''
                            while k <= 20:
                                var = text[idx + k]
                                k=k+1
                                Salcode = Salcode + str(var)
 
                               
                               
                            count = count + 1
                            worksheet.write(colIDC, str(Salcode))
                            worksheet.write(colIDD, str(len(images)))
                            print(Salcode)
                            Salcode = Salcode.replace("\n2\n","")
                # worksheet.write(colIDE, str(seq))
 
                conn = pyodbc.connect('Driver={SQL Server};'
                                                'Server=172.16.129.195;'
                                                'Database=TridentAttendance;'
                                                'uid=sa;'
                                                'pwd=Trident@5050')
 
 
                cursor = conn.cursor()
                fileNew = Salcode +".pdf"
                   
            shutil.move(os.path.join(your_path, file),os.path.join(New_path, fileNew))
            print(count)
    workbook.close()
except Exception as e:
                    with open("C:\Work\log.txt", 'a') as f:
                        f.write(str(e))
         