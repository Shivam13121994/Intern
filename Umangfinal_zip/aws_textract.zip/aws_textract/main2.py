from flask import Flask, jsonify, request
import boto3
import os
import uuid;

app = Flask(__name__)

# Initialize Textract client
def initialize_textract_client():
    return boto3.client('textract',
                        aws_access_key_id="AKIAQ3EGWHSNRCBIRJIV",
                        aws_secret_access_key="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",
                        region_name="ap-south-1")

# Function to detect text in an image
# def detect_text(image_bytes):
#     try:
#         textract_client = initialize_textract_client()
#         response = textract_client.detect_document_text(Document={'Bytes': image_bytes})
#         return response
#     except Exception as e:
#         return {'error': str(e)}

def load_image_from_path(image_path):
    try:
        textract_client = initialize_textract_client()
        with open(image_path, 'rb') as file:
            image_bytes = textract_client.analyze_document(
                Document={
                    
                    'Bytes': file.read(),
                },
                FeatureTypes=["FORMS","TABLES"])
        return image_bytes
    except Exception as e:
        return None

def extract_text_by_block_type(response, block_type):
    word_map={}
    for item in response['Blocks']:
        if item['BlockType'] == block_type:
            word_map[item["Id"]]=item["Text"]
        if item['BlockType']=="SELECTION_ELEMENT":
            word_map[item["Id"]]=item["SelectionStatus"]
    return word_map
def extract_table_info(response, word_map):
    row = []
    table = {}
    ri = 0
    flag = False

    for block in response["Blocks"]:
        if block["BlockType"] == "TABLE":
            key = f"table_{uuid.uuid4().hex}"
            table_n = +1
            temp_table = []

        if block["BlockType"] == "CELL":
            if block["RowIndex"] != ri:
                flag = True
                row = []
                ri = block["RowIndex"]

            if "Relationships" in block:
                for relation in block["Relationships"]:
                    if relation["Type"] == "CHILD":
                        row.append(" ".join([word_map[i] for i in relation["Ids"]]))
            else:
                row.append(" ")

            if flag:
                temp_table.append(row)
                table[key] = temp_table
                flag = False
    return table

@app.route('/textract_text', methods=['POST'])
def read_text():
    try:
        json_data = request.get_json()
        image_path = json_data.get('image_path', None)
        
        if not image_path:
            return jsonify({'message': 'Image path not provided'})
        
        # Load image from path
        image_bytes = load_image_from_path(image_path)
        print(image_bytes)
        
        if not image_bytes:
            return jsonify({'message': 'Failed to load image'})
        
        # response = detect_text(image_bytes)
        # print(response)
        
        # if 'error' in response:
        #     return jsonify({'message': 'Text detection failed'})
        
        block_type = 'WORD'
        extracted_text = extract_text_by_block_type(image_bytes, block_type)
        extracted_table=extract_table_info(image_bytes,extracted_text )
        
        return jsonify({'message': 'Text extracted successfully', 'text': extracted_table})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(host='0.0.0.0')
