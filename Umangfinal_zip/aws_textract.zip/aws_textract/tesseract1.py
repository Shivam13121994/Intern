from pdf2image import convert_from_path
import cv2
import pyodbc
import os
import shutil
import xlsxwriter
import boto3
from flask import Flask, request, jsonify

from datetime import datetime
os.environ['AWS_ACCESS_KEY_ID'] = 'AKIAQ3EGWHSNRCBIRJIV'
os.environ['AWS_SECRET_ACCESS_KEY'] = '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'
os.environ['AWS_DEFAULT_REGION'] = 'ap-south-1'

def initialize_textract_client():
    return boto3.client('textract')

def load_image_from_path(image_path):
    try:
        textract_client = initialize_textract_client()
        with open(image_path, 'rb') as file:
            response = textract_client.analyze_document(
                Document={
                    'Bytes': file.read(),
                },
                FeatureTypes=["FORMS", "TABLES"]
            )
        return response
    except Exception as e:
        print("Error:", e)
        return None

def extract_text_from_block(response, block_type):
    extracted_text = ""
    for item in response['Blocks']:
        if item['BlockType'] == block_type:
            extracted_text += item['Text'] + " "
    return extracted_text.strip()

# def read_text():
#     try:
#         json_data = request.get_json()
#         image_path = json_data.get('image_path', None)
        
#         if not image_path:
#             return jsonify({'message': 'Image path not provided'})
        
#         # Load image from path
#         response = load_image_from_path(image_path)
        
#         if not response:
#             return jsonify({'message': 'Failed to load image'})
        
#         # Extract text
#         block_type = 'WORD'
#         extracted_text = extract_text_from_block(response, block_type)
        
#         return jsonify({'message': 'Text extracted successfully', 'text': extracted_text})
#     except Exception as e:
#         return jsonify({'error': str(e)})

try:
    now = datetime.now()
    filename = str(now).replace("-", "").replace(" ", "").replace(":", "")[:12]

    workbook = xlsxwriter.Workbook('text' + filename + '.xlsx')
    worksheet = workbook.add_worksheet()

    worksheet.write('A1', 'ID')
    worksheet.write('B1', 'FileName')
    worksheet.write('C1', 'SalaryCode')
    worksheet.write('D1', 'PageCount')

    fileSplitCount = 0  
    # your_path = "C:\\Work\\scanned docs\\"
    # new_path = "C:\\Work\\scanned docs_Completed\\"
    your_path="/Users/trident/Desktop/Umang/aws_textract/input"
    new_path="/Users/trident/Desktop/Umang/aws_textract/output"

    id = 0
    # textract_response = load_image_from_path('sampletext1.jpeg')
    # text = extract_text_from_block(textract_response, 'WORD')
    # print(text)

    files = os.listdir(your_path)

    for file in files:
        if file.endswith('.pdf'):
            id += 1    
            colIDA = 'A'+ str(id+1)
            colIDB = 'B'+ str(id+1)
            colIDC = 'C'+ str(id+1)
            colIDD = 'D'+ str(id+1)
            worksheet.write(colIDA, str(id))
            worksheet.write(colIDB, file)
        
            images = convert_from_path(your_path + file, 100, output_folder=r'/Users/trident/Desktop/Umang/aws_textract/images')

            count = 0
            seq = ""
            for i, image in enumerate(images):
                image.save('/Users/trident/Desktop/Umang/aws_textract/images' + str(i) + '.png', 'PNG')
                img = cv2.imread(r'/Users/trident/Desktop/Umang/aws_textract/images' + str(i) + '.png')
                gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

                textract_response = load_image_from_path(r'/Users/trident/Desktop/Umang/aws_textract/images' + str(i) + '.png')
                if textract_response:
                    text = extract_text_from_block(textract_response, 'WORD')
                    print(text)
                    idx = text.find('Member Code')
                    if idx == -1:
                        idx = text.find('Member Coie')
                    idx2 = text.find('Place:')
                    page1 = text.find('This Appointment Letter is being executed based')
                    page2 = text.find('That all communications sent to you by')
                    page3 = text.find('You agree to submit to the exclusive jurisdiction')
                    page4 = text.find('ANNEXURE-A')
                    page5 = text.find('ANNEXURE-B')

                    if (page1 != -1):
                        seq += '1'
                    if (page2 != -1):
                        seq += '2'
                    if (page3 != -1):
                        seq += '3'
                    if (page4 != -1):
                        seq += '4'
                    if (page5 != -1):
                        seq += '5'
                    
                    if idx != -1:
                        Salcode = text[idx + 13:idx + 20].replace("\n2\n", "")
                        count += 1
                        worksheet.write(colIDC, str(Salcode))
                        worksheet.write(colIDD, str(len(images)))
                        conn = pyodbc.connect('Driver={SQL Server};'
                                            'Server=172.16.129.195;'
                                            'Database=TridentAttendance;'
                                            'uid=sa;'
                                            'pwd=Trident@5050')
                        cursor = conn.cursor()
                        file_new = Salcode + ".pdf"
                        shutil.move(os.path.join(your_path, file), os.path.join(new_path, file_new))
            print(count)
    workbook.close()
except Exception as e:
    with open("C:\Work\log.txt", 'a') as f:
        f.write(str(e))
