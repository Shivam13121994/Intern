from flask import Flask, request, jsonify
import boto3
import os

app = Flask(__name__)

# AWS S3 configurations
S3_BUCKET = 'mobile-app-textract'
S3_ACCESS_KEY = 'AKIAQ3EGWHSN7TLK4P6L'
S3_SECRET_KEY = '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'
S3_REGION = 'ap-south-1'

# Create an S3 client
s3 = boto3.client(
    's3',
    aws_access_key_id=S3_ACCESS_KEY,
    aws_secret_access_key=S3_SECRET_KEY,
    region_name=S3_REGION
)

@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        data = request.get_json()

        if 'file_path' not in data:
            return jsonify({'error': 'File path not provided'}), 400

        file_path = data['file_path']

        if not os.path.isfile(file_path):
            return jsonify({'error': 'File not found at the provided path'}), 400

        # Extract file name from the provided path
        filename = os.path.basename(file_path)

        # Open the file
        with open(file_path, 'rb') as file:
            # Upload the file to S3
            s3.upload_fileobj(
                file,
                S3_BUCKET,
                filename,
            )

            # Generate the URL for the uploaded file
            file_url = f"https://{S3_BUCKET}.s3.{S3_REGION}.amazonaws.com/{filename}"

            return jsonify({'success': True, 'file_url': file_url}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0')